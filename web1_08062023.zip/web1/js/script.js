var thongke = document.getElementById("stat");
thongke.innerHTML = "<h1>Đây là thống kê mới hơn</h1>";